<header>
<div><a id="touch-menu" class="mobile-menu nmp" href="#" style="overflow: hidden"><em class="fa fa-bars"></em>&nbsp;&nbsp;Menu</a>
<nav>
<ul class="menu">
<li><a href="">Αναρτήσεις </a></li>
<li><a href="">Νέα Αναρτηση</a></li>
<li><a href="">Μαθήματα</a></li>
<li><a href="">Χρήστες</a></li>
<li><a href="">Εκπαιδευτικοί</a></li>
<li><a href="">Μαθητές</a></li>
</ul>    
<div class="header-right">
<a href="" class="signin"><i class="fas fa-sign-out-alt"></i>&nbsp;&nbsp;Αποσύνδεση</a>
</div>
</nav>
</div>
</header>

