<footer>
<div class="row">
<div class="col-md-3">
<p><a href="https://sgschool.gr/gumnasio/">Αρχική</a></p>
<p><a href="https://sgschool.gr/gumnasio/anakoinwseis">Ανακοινώσεις</a></p>
<p><a href="https://sgschool.gr/gumnasio/episkepseis">Επισκέψεις - Εκδρομές</a></p>
<p><a href="https://sgschool.gr/gumnasio/draseis">Δράσεις - Προγράμματα</a></p>
<p><a href="https://sgschool.gr/gumnasio/ekpaideutikoi">Εκπαιδευτικοί</a></p>
</div>
<div class="col-md-3">
<p><a href="https://sgschool.gr/gumnasio/kanonismos">Κανονισμός Λειτουργίας</a></p>
<p><a href="https://sgschool.gr/gumnasio/privacy">Προσωπικά Δεδομένα</a></p>
<p><a href="https://sgschool.gr/gumnasio/contact">Επικοινωνία</a></p>
</div>
<div class="col-md-3">
<p><a href="https://sgschool.gr/daycare/index" target="blank">Παιδικός Σταθμός</a></p>
<p><a href="https://sgschool.gr/kindergarden/index" target="blank">Νηπιαγωγείο</a></p>
<p><a href="https://sgschool.gr/elementary/index" target="blank">Δημοτικό</a></p>
<p><a href="https://sgschool.gr" target="blank">Κεντρική Σελίδα Σχολείου</a></p>
</div>
<div class="col-md-3">
<p class="foot">Εκπαιδευτήρια ΔΕΛΑΣΑΛ Σύρου</p>
<p class="foot">Βαμβακάρειο Γυμνάσιο</p>
<p class="foot">Ανδρέα Κάργα 12 -14</p>
<p class="foot">Σύρος, 84100</p>
<p class="foot">22810 87713</p>
<p class="foot">&copy;&nbsp; Εκπαιδευτήρια ΔΕΛΑΣΑΛ Σύρου 2019</p>
</div>
</div>   
</footer>