<?php
//session_start();
$page = "test-2.php";
require "../../Gumnasio/loader.php";
use App\Controllers\ERouteGenerator;
?>

<div>hello from test 2</div>