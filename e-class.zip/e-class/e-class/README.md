# e-class

-------------------------
eclass Project
Creator: Stamatis Strongylis

Written in:

PHP
HTML5, CSS3, Javascript

This a project currently under development
-------------------------


-------------------------
1. Project Description and Features
-------------------------

This project is intended to be used from Primary and Middle Level Educational Institutions.

It is abstracted and almost ready to be installed and added to any existing website.

Features:

a. Support of three different user roles: Administrator, Teacher, Parent/Student
b. Management of classes, lessons, students, parents, teachers, users
c. Communication System for Daily Interaction between school staff and parents/students
d. Message System, Announcements
e. Online Exercises and Online Assignements creation by teachers and students


For more information please contacton the following email address:

codenesting@gmail.com 
