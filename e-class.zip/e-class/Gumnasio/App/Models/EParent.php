<?php

namespace App\Models;

class EParent {
    
    public $parent_id;
    public $parent_email;
    public $lastname;
    public $firstname;
    public $phone;
    public $tmima;
    public $timestamp;
    
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>