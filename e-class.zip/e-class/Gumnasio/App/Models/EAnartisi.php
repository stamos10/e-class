<?php

namespace App\Models;

class EAnartisi {
    
    public $id;
    public $title;
    public $tmima;
    public $type;
    public $content_init;
    public $content;
    public $url;
    public $sender_email;
    public $mathima_id;
    public $receiver_email;
    public $timestamp;
    
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>