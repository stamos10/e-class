<?php

namespace App\Models;

class Ekpaideutikos {
    
    public $id;
    public $lastname;
    public $firstname;
    public $eidikotita;
    public $tmima;
    public $wres;
    public $timestamp;

        
    function __construct(){
        

    }
    
    function __destruct(){
        
       
    }
    
    
    
    
    
}

?>