<?php

namespace App\Models;

class EOnlineErgasia extends EAnartisi {
    
    public $id;
    public $content;  
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>