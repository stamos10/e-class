<?php

namespace App\Models;

class EAnakoinwsi extends EAnartisi {
    
    public $id;
    public $content;
    public $episunaptomeno_url;    
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>