<?php

namespace App\Models;

class ETmima {
    
    public $student_id;
    public $tmima;    
    public $timestamp;
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>