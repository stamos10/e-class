<?php

namespace App\Models;

class Kanonismos {
    
    public $id;
    public $title;
    public $content;
    public $timestamp;

        
    function __construct(){
        

    }
    
    function __destruct(){
        
       
    }
    
    
    
    
    
}

?>