<?php

namespace App\Models;

class Anakoinwsi {
    
    public $id;
    public $title;
    public $content;
    public $image_url_a;
    public $timestamp;

        
    function __construct(){
        

    }
    
    function __destruct(){
        
       
    }
    
    
    
    
    
}

?>