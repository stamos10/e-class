<?php

namespace App\Models;

class EMathima {
    
    public $id;
    public $title;
    public $tmima;
    public $teacher_email;
    public $teacher_firstname;
    public $teacher_lastname;
    public $student_email;
    public $ergasia_id;
    public $online_ergasia_id;
    public $anakoinwsi_id;
    public $daily_report_id;
    public $timestamp;
    
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>