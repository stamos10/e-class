<?php

namespace App\Models;

class EStudent {
    
    public $student_id;
    public $student_email;
    public $lastname;
    public $firstname;
    public $fathername;
    public $mothername;
    public $phone;
    public $tmima;
    public $timestamp;
    
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>