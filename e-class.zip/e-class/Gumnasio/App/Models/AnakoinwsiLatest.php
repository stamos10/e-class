<?php

namespace App\Models;

class AnakoinwsiLatest {
    
    public $id;
    public $title;
    public $promo;
    public $content;
    public $image_url_a;
    public $timestamp;

        
    function __construct(){
        

    }
    
    function __destruct(){
        
       
    }
    
    
    
    
    
}

?>