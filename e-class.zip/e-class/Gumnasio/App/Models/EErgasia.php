<?php

namespace App\Models;

class EErgasia extends EAnartisi {
    
    public $id;
    public $content;
    public $document_url;    
    
    public function __construct(){
        
    }
    
    public function __destruct(){
        
    }
    
}


?>