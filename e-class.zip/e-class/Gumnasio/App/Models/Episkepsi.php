<?php

namespace App\Models;

class Episkepsi {
    
    public $id;
    public $title;
    public $content;
    public $image_url_a;
    public $image_url_b;
    public $image_url_c;
    public $image_url_d;
    public $template_choice;
    public $timestamp;

        
    function __construct(){
        

    }
    
    function __destruct(){
        
       
    }
    
    
    
    
    
}

?>